class voiturier:
    def __init__(self,numVoiturier):
        self.numVoiturier = numVoiturier

    def livrerVoiture(self):
        pass