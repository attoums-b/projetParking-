#les models sont les entités principales de notre programme


from composants import camera


class Parking:
    def __init__(self,nbNiveaux,prix):
        self.places = []
        self.nbNiveaux = nbNiveaux
        self.prix = prix



    def ajouterPlaceParking(self,p):
        self.places.append(p)

    def nbPlaces(self):
        return len(self.places)
    
    def nbPlacesLibres(self):
        placesLibres = 0
        for p in self.places:
            if p.estLibre:
                placesLibres += 1

        return placesLibres


           

    def rechercherPlace(self):
        #on parcours la liste de places
        for p in self.places:
            if p.estLibre:
                return p 
        return None
                #attribuer la premiere place disponible par ordre 

    def nbPlaces(self):
        return len(self.places)

    #rechercher les places ou il n'ya pas de voitures pour chaque niveau
    def NbPlacesLibresParNiveau(self,n):
        pass


    def attribuerPlaceVoit(self,v):
        place_libre = self.rechercherPlace()
        if place_libre:
            place_libre.occuperPlace(v)
            v.place = place_libre
            print(f"la voiture numero {v.immatriculation} occupe maintenant la place {place_libre.id_place}")

        else:
            print(f"Aucune place disponible")


    def retirerPlaceVoit(self,v):
        if v.place is not None:
            place_occupee = v.place
            place_occupee.libererPlace(v)
            v.place = None 




