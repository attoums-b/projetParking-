class voiture:
    def __init__(self,hauteur,longueur,immatriculation):
        self.hauteur = hauteur
        self.longueur = longueur
        self.immatriculation = immatriculation 
        self.place = None # la voiture n'a pas encore de places


    def addPlacement(self,p):
        pass