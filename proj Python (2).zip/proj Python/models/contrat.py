class Contrat:
    def __init__(self, dateDebut,dateFin,estEnCours):
        self.dateDebut = dateDebut
        self.dateFin = dateFin
        self.estEnCours = estEnCours

    def rompreContrat():
        pass 