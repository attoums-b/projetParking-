import parking

class Place:
    niveaux = ['A', 'B', 'C', 'D', 'E']
    compteur = {niveau: 0 for niveau in parking.niveaux}
 
    
    def __init__(self,niveau,longueur,hauteur,estLibre = True):

        Place.compteur[niveau] += 1

        self.numero =Place.compteur[niveau]
        self.idPlace = f"{niveau}{self.numero}"
        self.longueur = longueur
        self.estLibre = estLibre
        self.hauteur = hauteur



    def estOccupe(self):
        return self.estLibre ==  False
    
    #attribuer une place à une voiture et mettre estLibre à false
    def occuperPlace(self,voiture):
        self.voiture = voiture
        self.estLibre = False


    def libererPlace(self):
        self.voiture = None 
        self.estLibre = True









