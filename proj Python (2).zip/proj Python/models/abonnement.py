class Abonnement:
    def __init__(self,libelle,prix,estPackGar):
        self.libelle = libelle 
        self.prix = prix
        self.estPackGar = estPackGar

    def ajouterContrat():
        pass