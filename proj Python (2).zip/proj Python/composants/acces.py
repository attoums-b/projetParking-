from camera import Camera
from panneau_affichage import PanneauAffichage
from borne import Borne_ticket
class Acces:
    def __init__(self,parking):
        self.parking = parking
        self.camera = Camera()
        self.panneau = PanneauAffichage()
        self.borne = Borne_ticket()

       
    def actionnerCamera(self, voiture):
        # si il y'a une voiture
        if voiture:
        #j'appelle les methodes que doit faire la camera
            hauteur = self.camera.capturerHauteurVoit(voiture)
            longueur = self.camera.capturerLongueurVoit(voiture)
            immat = self.camera.capturerImmat(voiture)
            print(f"Voiture détectée par la camera! : {immat}, hauteur={hauteur}, longueur={longueur}")

    def actionnerPanneau(self,voiture):
        if voiture:
            self.panneau.afficher_instructions()
            self.panneau.proposerAbonnement()
   
   
    def lancerProcedureEntree(self,client):
        pass