class teleporteur:
    def teleportVoiture(self,v,p):
        pass

    def teleportVoitSuperAbonne(self,v):
        pass

