from models import client 

class Borne_ticket:
    def delivrerTicket(self,c):
        #si le client a payé le montant alors on lui donne ce ticket
        #ici j'affiche juste à quoi ressemblerait un ticket 
        print("""

        TICKET DE PAIEMENT DE PARKING:
              
            Montant : 
            Date : 
            Heure :
              
            Nom du client : 
              
""")
        

    def recupererInfosCarte(self,c):
        pass

   

        

