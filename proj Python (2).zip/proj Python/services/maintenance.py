from service import Service


class Maintenance(Service):
    #on effectue une maintenance sur une voiture
    def effectuerMaintenance(self,v):
        pass
