from service import Service 


class Livraison(Service):
    
    def effectuerLivraison():
        pass    