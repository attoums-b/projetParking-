from service import Service


class Entretien(Service):
    def effectuerEntretien():
        pass