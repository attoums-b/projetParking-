class Service:
    def __init__(self,dateDemande, dateService, rapport):
        self.dateDemande = dateDemande
        self.dateService = dateService
        self.rapport = rapport 


        


    